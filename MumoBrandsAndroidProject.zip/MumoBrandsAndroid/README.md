# Mumo Brands Printing and Branding Services

Fresh native Android project scaffold inspired by the supplied UI reference.

## Included
- Navy / magenta / royal-blue brand palette and MB-style dashboard
- Collapsible navigation drawer; tapping outside closes it (Material 3 modal drawer)
- Orders with status filters and new-order entry
- Product inventory and client entry/list screens
- Reports summary based on locally saved orders
- Room database stored in the app's private internal storage
- GitHub Actions workflow to build and upload a debug APK

## Build
Open this folder in Android Studio (Hedgehog or newer), use JDK 17, allow Gradle sync, then run:
`gradle :app:assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

Or push to GitHub and run the **Build Mumo Brands APK** workflow under Actions.
The workflow installs Gradle 8.13 and JDK 17, builds the debug APK, and publishes it as
the `Mumo-Brands-debug-apk` workflow artifact.

## Notes
This is a starter implementation, not a verified release build. Test on a device before business use.
The order/product/client forms and lists are initial CRUD foundations. Payment integration, advanced stock movements,
editing/deleting screens, printing, authentication, data export/backup, and production signing still need implementation.
The UI reference image is supplied separately and can be kept as the design brief.
