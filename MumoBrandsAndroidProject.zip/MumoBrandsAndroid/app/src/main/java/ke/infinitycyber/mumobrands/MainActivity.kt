package ke.infinitycyber.mumobrands

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import ke.infinitycyber.mumobrands.data.*
import ke.infinitycyber.mumobrands.ui.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(this).dao()
        setContent { MumoTheme { MumoApp(dao) } }
    }
}

private enum class Page(val label: String) {
    Home("Home"), Orders("My Orders"), Inventory("Inventory"), Clients("Clients"),
    Reports("Reports"), Settings("Settings"), About("About Us"), Help("Help & Support")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MumoApp(dao: BusinessDao) {
    var page by remember { mutableStateOf(Page.Home) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var showOrder by remember { mutableStateOf(false) }
    var showProduct by remember { mutableStateOf(false) }
    var showClient by remember { mutableStateOf(false) }
    val orders by dao.orders().collectAsStateWithLifecycle(emptyList())
    val products by dao.products().collectAsStateWithLifecycle(emptyList())
    val clients by dao.clients().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.fillMaxWidth(.84f)) {
                Column(Modifier.fillMaxWidth().background(Navy).padding(20.dp)) {
                    Text("MB", color = Magenta, fontSize = 42.sp, fontWeight = FontWeight.Black)
                    Text("MUMO BRANDS", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Printing and Branding Services", color = Color.White)
                }
                Page.values().forEach { item ->
                    NavigationDrawerItem(
                        label = { Text(item.label) },
                        selected = page == item,
                        onClick = { page = item; scope.launch { drawerState.close() } },
                        icon = { Icon(pageIcon(item), null) },
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
                NavigationDrawerItem(
                    label = { Text("Logout / Exit") },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.ExitToApp, null) },
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
                Spacer(Modifier.weight(1f))
                Text("∞  Infinity Cyber Technologies", Modifier.padding(18.dp), color = Navy, fontSize = 12.sp)
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Mumo Brands Printing\nand Branding Services", fontSize = 17.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold, color = Color.White) },
                    navigationIcon = { IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "Home menu", tint = Color.White) } },
                    actions = { IconButton(onClick = {}) { Icon(Icons.Default.Notifications, "Notifications", tint = Color.White) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf(Page.Home, Page.Orders, Page.Inventory, Page.Clients, Page.Reports).forEach { item ->
                        NavigationBarItem(
                            selected = page == item, onClick = { page = item },
                            icon = { Icon(pageIcon(item), null) }, label = { Text(item.label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Magenta, selectedTextColor = Magenta)
                        )
                    }
                }
            },
            containerColor = Pale
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                when (page) {
                    Page.Home -> HomePage(orders.size, products.size, clients.size,
                        onPage = { page = it }, onNewOrder = { showOrder = true })
                    Page.Orders -> OrdersPage(orders, onAdd = { showOrder = true })
                    Page.Inventory -> InventoryPage(products, onAdd = { showProduct = true })
                    Page.Clients -> ClientsPage(clients, onAdd = { showClient = true })
                    Page.Reports -> ReportsPage(orders, products.size, clients.size)
                    Page.Settings -> InfoPage("Settings", "Application preferences and business profile.")
                    Page.About -> InfoPage("About Mumo Brands", "Quality • Creativity • Your Brand")
                    Page.Help -> InfoPage("Help & Support", "Contact 0741 167 612 for assistance.")
                }
            }
        }
    }

    if (showOrder) EntryDialog(
        title = "New Order",
        labels = listOf("Client name", "Item / branding", "Quantity", "Amount (KSh)"),
        onSave = { v ->
            val q = v.getOrNull(2)?.toIntOrNull() ?: 1
            val a = v.getOrNull(3)?.toIntOrNull() ?: 0
            scope.launch { dao.addOrder(OrderEntity(client=v[0], item=v[1], quantity=q, amount=a)) }
            showOrder = false
        },
        onDismiss = { showOrder = false }
    )
    if (showProduct) EntryDialog(
        title = "Add Product",
        labels = listOf("Product name", "Category", "Stock quantity", "Unit price (KSh)"),
        onSave = { v ->
            scope.launch { dao.addProduct(ProductEntity(name=v[0], category=v[1], stock=v[2].toIntOrNull() ?: 0, unitPrice=v[3].toIntOrNull() ?: 0)) }
            showProduct = false
        },
        onDismiss = { showProduct = false }
    )
    if (showClient) EntryDialog(
        title = "Add Client",
        labels = listOf("Client / organization", "Phone number", "Organization details"),
        onSave = { v ->
            scope.launch { dao.addClient(ClientEntity(name=v[0], phone=v[1], organization=v[2])) }
            showClient = false
        },
        onDismiss = { showClient = false }
    )
}

@Composable
private fun HomePage(orderCount: Int, productCount: Int, clientCount: Int, onPage: (Page)->Unit, onNewOrder: ()->Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp)) {
        Box(Modifier.fillMaxWidth().height(190.dp).background(
            androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color.White, Color(0xFFE8E9FF))),
            RoundedCornerShape(22.dp)
        ).padding(18.dp), contentAlignment = Alignment.CenterStart) {
            Column {
                Text("MB", color = Magenta, fontSize = 48.sp, fontWeight = FontWeight.Black)
                Text("MUMO BRANDS", color = Magenta, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Text("...Quality and perfection", color = Navy, fontWeight = FontWeight.Bold)
                Text("Your Brand, Our Priority", color = Color.White,
                    modifier = Modifier.padding(top=10.dp).background(Navy, RoundedCornerShape(20.dp)).padding(horizontal=14.dp, vertical=6.dp))
            }
            Image(
                painter = painterResource(id = R.drawable.mb_brand_mark),
                contentDescription = "Mumo Brands MB company logo",
                modifier = Modifier.align(Alignment.CenterEnd).size(112.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        Text("Quick actions", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Navy)
        val actions = listOf(
            Triple("New Order", Icons.Default.ShoppingCart, Magenta),
            Triple("My Orders", Icons.Default.ReceiptLong, RoyalBlue),
            Triple("Inventory", Icons.Default.Checkroom, DeepNavy),
            Triple("Clients", Icons.Default.Groups, RoyalBlue),
            Triple("Reports", Icons.Default.BarChart, Magenta),
            Triple("Settings", Icons.Default.Settings, DeepNavy),
            Triple("Print Labels & Receipts", Icons.Default.Print, RoyalBlue),
            Triple("About Us", Icons.Default.Info, Magenta),
            Triple("Exit", Icons.Default.ExitToApp, RoyalBlue)
        )
        actions.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (label, icon, color) ->
                    Card(
                        onClick = { when(label) {
                            "New Order" -> onNewOrder()
                            "My Orders" -> onPage(Page.Orders)
                            "Inventory" -> onPage(Page.Inventory)
                            "Clients" -> onPage(Page.Clients)
                            "Reports" -> onPage(Page.Reports)
                            "Settings" -> onPage(Page.Settings)
                            "About Us" -> onPage(Page.About)
                            else -> onPage(Page.Help)
                        } },
                        modifier = Modifier.weight(1f).height(104.dp),
                        colors = CardDefaults.cardColors(containerColor = color),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(icon, null, tint = Color.White, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
                if (row.size < 3) repeat(3-row.size) { Spacer(Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(10.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Metric("Orders", orderCount.toString(), RoyalBlue)
            Metric("Products", productCount.toString(), Magenta)
            Metric("Clients", clientCount.toString(), DeepNavy)
        }
        Spacer(Modifier.height(10.dp))
        Text("Quality • Creativity • Your Brand", Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(12.dp)).padding(14.dp), color=Color.White, fontWeight=FontWeight.Bold)
        Text("☎  0741 167 612", Modifier.align(Alignment.CenterHorizontally).padding(8.dp), color=Navy, fontWeight=FontWeight.Bold)
    }
}

@Composable private fun Metric(label: String, value: String, color: Color) {
    Card(Modifier.width(104.dp), colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(12.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Text(value, color=color, fontWeight=FontWeight.ExtraBold, fontSize=22.sp)
            Text(label, color=Navy, fontSize=11.sp)
        }
    }
}

@Composable private fun OrdersPage(data: List<OrderEntity>, onAdd: ()->Unit) {
    var filter by remember { mutableStateOf("All") }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("All","Pending","Processing","Delivered").forEach { f ->
                FilterChip(selected=filter==f, onClick={filter=f}, label={Text(f, fontSize=11.sp)})
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(data.filter { filter=="All" || it.status==filter }) { o ->
                Card(Modifier.fillMaxWidth().padding(vertical=5.dp), colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Order #ORD-${o.id.toString().padStart(6,'0')}", color=Navy, fontWeight=FontWeight.Bold)
                        Text("Client: ${o.client}")
                        Text("${o.quantity} × ${o.item}")
                        Text("KSh ${o.amount}", color=Magenta, fontWeight=FontWeight.Bold)
                        Text(o.status, color=RoyalBlue, fontSize=12.sp)
                    }
                }
            }
        }
        Button(onClick=onAdd, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("  New Order") }
    }
}

@Composable private fun InventoryPage(data: List<ProductEntity>, onAdd: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        LazyColumn(Modifier.weight(1f)) {
            items(data) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical=5.dp), colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.Checkroom, null, tint=Magenta, modifier=Modifier.size(40.dp))
                        Column(Modifier.weight(1f).padding(start=12.dp)) {
                            Text(p.name, fontWeight=FontWeight.Bold, color=Navy)
                            Text("${p.category} • Stock: ${p.stock}")
                            Text("Price: KSh ${p.unitPrice}")
                        }
                    }
                }
            }
        }
        Button(onClick=onAdd, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("  Add Product") }
    }
}

@Composable private fun ClientsPage(data: List<ClientEntity>, onAdd: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        LazyColumn(Modifier.weight(1f)) {
            items(data) { c ->
                Card(Modifier.fillMaxWidth().padding(vertical=5.dp), colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.Business, null, tint=RoyalBlue, modifier=Modifier.size(36.dp))
                        Column(Modifier.padding(start=12.dp)) {
                            Text(c.name, color=Navy, fontWeight=FontWeight.Bold)
                            Text(c.phone)
                            Text(c.organization, fontSize=12.sp)
                        }
                    }
                }
            }
        }
        Button(onClick=onAdd, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("  Add Client") }
    }
}

@Composable private fun ReportsPage(orders: List<OrderEntity>, products: Int, clients: Int) {
    val revenue = orders.sumOf { it.amount }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Business overview", color=Navy, fontWeight=FontWeight.Bold, fontSize=20.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Metric("Orders", orders.size.toString(), RoyalBlue)
            Metric("Items", products.toString(), Magenta)
            Metric("Clients", clients.toString(), DeepNavy)
        }
        Spacer(Modifier.height(16.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(20.dp)) {
                Text("Recorded order value", color=Navy)
                Text("KSh %,d".format(revenue), color=Magenta, fontSize=28.sp, fontWeight=FontWeight.ExtraBold)
                Text("Calculated from orders saved on this device.", fontSize=12.sp)
            }
        }
    }
}

@Composable private fun EntryDialog(title: String, labels: List<String>, onSave: (List<String>)->Unit, onDismiss: ()->Unit) {
    val values = remember { mutableStateListOf<String>().also { list -> repeat(labels.size) { list.add("") } } }
    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text(title, color=Navy, fontWeight=FontWeight.Bold)},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                labels.forEachIndexed { i, label ->
                    OutlinedTextField(value=values[i], onValueChange={values[i]=it}, label={Text(label)}, singleLine=true)
                }
            }
        },
        confirmButton={ TextButton(onClick={ if(values.take(2).all { it.isNotBlank() }) onSave(values.toList()) }) { Text("Save") } },
        dismissButton={ TextButton(onClick=onDismiss) { Text("Cancel") } }
    )
}

@Composable private fun InfoPage(title: String, body: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
        Text(title, color=Navy, fontSize=24.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp)); Text(body, color=Navy)
    }
}

private fun pageIcon(page: Page) = when(page) {
    Page.Home -> Icons.Default.Home
    Page.Orders -> Icons.Default.ShoppingCart
    Page.Inventory -> Icons.Default.Inventory2
    Page.Clients -> Icons.Default.Groups
    Page.Reports -> Icons.Default.BarChart
    Page.Settings -> Icons.Default.Settings
    Page.About -> Icons.Default.Info
    Page.Help -> Icons.Default.SupportAgent
}
