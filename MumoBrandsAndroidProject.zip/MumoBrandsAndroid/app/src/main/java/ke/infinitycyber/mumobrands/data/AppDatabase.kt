package ke.infinitycyber.mumobrands.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BusinessDao {
    @Query("SELECT * FROM orders ORDER BY id DESC")
    fun orders(): Flow<List<OrderEntity>>
    @Insert suspend fun addOrder(order: OrderEntity)
    @Update suspend fun updateOrder(order: OrderEntity)
    @Delete suspend fun deleteOrder(order: OrderEntity)

    @Query("SELECT * FROM products ORDER BY name")
    fun products(): Flow<List<ProductEntity>>
    @Insert suspend fun addProduct(product: ProductEntity)
    @Update suspend fun updateProduct(product: ProductEntity)
    @Delete suspend fun deleteProduct(product: ProductEntity)

    @Query("SELECT * FROM clients ORDER BY name")
    fun clients(): Flow<List<ClientEntity>>
    @Insert suspend fun addClient(client: ClientEntity)
    @Update suspend fun updateClient(client: ClientEntity)
    @Delete suspend fun deleteClient(client: ClientEntity)
}

@Database(entities = [OrderEntity::class, ProductEntity::class, ClientEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): BusinessDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "mumo_brands_private.db"
            ).build().also { INSTANCE = it }
        }
    }
}
