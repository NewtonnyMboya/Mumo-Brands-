package ke.infinitycyber.mumobrands.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF090B67)
val DeepNavy = Color(0xFF10005D)
val Magenta = Color(0xFFE60078)
val RoyalBlue = Color(0xFF1769E8)
val Pale = Color(0xFFF4F5FF)

private val BrandColors = lightColorScheme(
    primary = Magenta, secondary = RoyalBlue, tertiary = DeepNavy,
    background = Pale, surface = Color.White, onPrimary = Color.White,
    onSecondary = Color.White, onBackground = Navy, onSurface = Navy
)

@Composable
fun MumoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = BrandColors, typography = Typography(), content = content)
}
